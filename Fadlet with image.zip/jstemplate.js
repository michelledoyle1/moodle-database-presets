 document.addEventListener("DOMContentLoaded", function () {
        const justratingsSection = document.getElementById('justratingssection');
        const ratingAggregateContainer = document.querySelector('.rating-aggregate-container');
        const ratingForm = document.querySelector('.ratingform');
        const mdlLeftContainer = document.querySelector('.mdl-left');
        const commentsRatingsSection = document.getElementById('commentsratingssection');
        const commentLink = document.querySelector('.comment-link');

        // Check if the target containers and the elements exist
        if (justratingsSection && ratingAggregateContainer && ratingForm) {
            // Move rating-aggregate-container, ratingform into justratingssection
            justratingsSection.appendChild(ratingAggregateContainer);
            justratingsSection.appendChild(ratingForm);
        }

        if (mdlLeftContainer && commentsRatingsSection && commentLink) {
            // Move mdl-left and comment-link into commentsratingssection and add a line break
            commentsRatingsSection.appendChild(mdlLeftContainer);
            commentsRatingsSection.appendChild(commentLink);
            commentsRatingsSection.appendChild(document.createElement('br'));

            // Set the width of mdlLeftContainer to 100%
            mdlLeftContainer.style.width = '100%';
        }

        // Add span.rating-aggregate-container to commentsratingssection
        const spanRatingAggregateContainer = document.createElement('span');
        spanRatingAggregateContainer.classList.add('rating-aggregate-container');
        commentsRatingsSection.appendChild(spanRatingAggregateContainer);
    });







// Colour for cards
document.addEventListener("DOMContentLoaded", function () {
    const cards = document.querySelectorAll('.card');

    cards.forEach(function (card) {
        const cardType = card.dataset.cardType; // Get the card_type value from data attribute
        const colorHex = getHexCode(cardType); // Get the corresponding hex code

        // Set the background color of the card
        card.style.backgroundColor = colorHex;

        // Apply the color to the specific div with id "singleviewsinglec"
        const singleViewSingleC = document.getElementById("singleviewsinglec");
        if (singleViewSingleC) {
            singleViewSingleC.style.backgroundColor = colorHex;
        }
    });

    function getHexCode(cardType) {
        const colorMap = {
            'Pink': '#FADADD',
            'Green': '#B2E5B1',
            'Lavender': '#E3D9FF',
            'Blue': '#B3D8F2',
            'Coral': '#FFD8B1',
            'Red': '#FFA07A',
            'Yellow': '#f0e9a9'
        };

        return colorMap[cardType] || '#FFFFFF'; // Default to white if no match found
    }
});

